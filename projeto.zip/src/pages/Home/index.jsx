import SaudacaoComponent from '../../components/saudacaoComponent';
import Logo from '../../assets/imgs/acai01.jpeg';

const HomePage = () => {
    const nome="World";
    
    return (
        <div>
          <img src={Logo} alt="açai" />
          <h1>Hello {nome}!</h1>
          <p>
            Testando jsx no React.
            <SaudacaoComponent nome="Luiz" />
          </p>
        </div>);
};

export default HomePage;