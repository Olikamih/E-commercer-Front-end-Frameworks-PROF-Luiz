import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import HomePage from './pages/Home/';
import UsuariosPage from './pages/Usuarios';
import BuscaCepPage from './pages/BuscaCep';
import CadClientePage from './pages/Cliente/cad';

const Sobre = () => <h1>Sobre Nós</h1>;

const App = () => {
    return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/usuarios" element={<UsuariosPage titulo="Lista de Cliente" />} />
          <Route path="/sobre" element={<Sobre />} />
          <Route path="/buscacep" element={<BuscaCepPage />} />
          <Route path="/cliente/cad" element={<CadClientePage />} />
        </Routes>
      </BrowserRouter>
      );
};
export default App;