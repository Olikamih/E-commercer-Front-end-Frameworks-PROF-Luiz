const SaudacaoComponent = ({nome}) => {
    return <h5>Olá, {nome} !!</h5>;

}

export default SaudacaoComponent;